
document.getElementById("colorButton").addEventListener("click", function () {
  const colors = ["#ff9999", "#66b3ff", "#99ff99", "#ffcc99", "#dabfff"];
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  this.style.backgroundColor = randomColor;
});

function showGreeting() {
  const hour = new Date().getHours();
  let message;

  if (hour < 12) {
    message = "Good Morning!";
  } else if (hour < 18) {
    message = "Good Afternoon!";
  } else {
    message = "Good Evening!";
  }

  alert(message);
}

function calculateSum() {
  const num1 = parseFloat(document.getElementById("num1").value);
  const num2 = parseFloat(document.getElementById("num2").value);

  if (isNaN(num1) || isNaN(num2)) {
    document.getElementById("result").innerText = "Please enter valid numbers!";
  } else {
    const sum = num1 + num2;
    document.getElementById("result").innerText = `Result: ${sum}`;
  }
}
